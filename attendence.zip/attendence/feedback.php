<?php

require_once(__DIR__ . '/../../config.php');
require_login();
require_once($CFG->libdir.'/formslib.php');
require_once($CFG->dirroot.'/local/attendence/classes/form/edit.php');

global $DB, $USER;


$feed=$_POST['feedback'];
$id=$_POST['id'];
// print_r($id);die;

if($id){
  $formdata = $DB->get_record('local_attendence', ['id' => $id]);
  // print_r($formdata); die;
  $updaterec->id = $formdata->id;
  $updaterec->uname = $formdata->uname;
  $updaterec->date = $formdata->date;
  $updaterec->status = $formdata->status;
  $updaterec->feedback = $feed;
  // print_r($updaterec);die;
  $DB->update_record('local_attendence', $updaterec);
  redirect($CFG->wwwroot . '/local/attendence/index.php', 'Feedback successfully added.');
}
