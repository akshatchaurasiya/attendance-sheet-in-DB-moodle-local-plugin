<?php

require_once(__DIR__ . '/../../config.php');
require_login();

global $DB, $PAGE, $USER;

$PAGE->requires->jquery();
$PAGE->requires->css(new moodle_url('https://cdn.datatables.net/1.11.5/css/jquery.dataTables.min.css'));
$PAGE->requires->js(new moodle_url('https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js'),true);
$PAGE->requires->js(new moodle_url('https://cdn.datatables.net/1.11.5/js/jquery.dataTables.js'),true);


$PAGE->set_url(new moodle_url('/local/attendence/index.php'));
$PAGE->set_context(\context_system::instance());
$PAGE->set_heading('Attendence');
$PAGE->set_title('attendence');
//$PAGE->navbar->add('Class Records', new moodle_url('/local/message/manage.php'));
$PAGE->navbar->add('');
$formid = optional_param('id', null, PARAM_INT);
 if($is_manager || is_siteadmin()) {
   $att = $DB->get_records('local_attendence');
   foreach ($att as $result) {
     $result->date    =   date('d-M-Y', $result->date);
   }

   // $sql = "SELECT uname, status FROM {local_attendence}";
   // $records = $DB->get_records_sql($sql);
   // // print_r($records);die;
   // $total = count($records,  COUNT_RECURSIVE);
   // print_r($total);die;
 }
 else {
   $att = $DB->get_records('local_attendence', ['uname'=>$USER->firstname]);
   foreach ($att as $result) {
     $result->date = date('d-M-Y', $result->date);
     if($result->status == 0){
       $result->status = 'Absent';
     }
     else {
       $result->status = 'Present';
     }
   }
 }


echo $OUTPUT->header();

$templatecontext = (object)[
  'att' => array_values($att),

  'form' => new moodle_url('/local/attendence/edit.php'),
  'feedback' => new moodle_url('/local/attendence/feedback.php'),
'varid'=>$USER->id,
 ];


 if($is_manager || is_siteadmin()) {
   echo $OUTPUT->render_from_template('local_attendence/manage1', $templatecontext);
 }
 else {
   echo $OUTPUT->render_from_template('local_attendence/manage2', $templatecontext);
 }


echo $OUTPUT->footer();













echo "<script>
$(document).ready(function() {
    $('#example').DataTable();
} );
</script>";
