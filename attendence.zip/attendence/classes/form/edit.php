<?php

//moodleform is defined in formslib.php
require_once("$CFG->libdir/formslib.php");

class edit extends moodleform {
    //Add elements to form
    public function definition() {
        global $DB, $CFG, $USER;

        $mform = $this->_form; // Don't forget the underscore!

        $formid=optional_param('id', null, PARAM_INT);

        $mform->addElement('hidden','id');
        $mform->setType('int', PARAM_INT);

        $varid=$DB->get_records('user', ['id' => $USER->id]);

        foreach ($varid as $key) {
          $firstname = $key->firstname;
          $lastname = $key->lastname;
          // $name=$firstname . $lastname;
          $name = ("{$firstname} {$lastname}");
        }

        // print_r($name);die;

        $mform->addElement('text', 'uname', 'User Name'); // Add elements to your form.
        $mform->disabledIf('uname', 'id', 'neq', 0);
        $mform->setType('uname', PARAM_NOTAGS);                   // Set type of element.
        $mform->setDefault('uname', $firstname);        // Default value.


        $mform->addElement('date_selector', 'date', 'Date'); // Add elements to your form.
        $mform->disabledIf('date', 'id', 'neq', 0);
        $mform->setType('date', PARAM_NOTAGS);                   // Set type of element.


        $options = [];
        $options[0] = 'Absent';
        $options[1] = 'Present';

        $mform->addElement('select', 'status', 'Status', $options);
        $mform->setDefault('0', $options);



        // $mform->addElement('recaptcha', 'recaptcha_field_name', $attributes);


        // $this->add_action_buttons();
        $this->add_action_buttons(true, get_string('present', 'local_attendence'));
        // $mform->addElement('button', 'Present', get_string('present', 'local_attendence'));



      }


    //Custom validation should be added here

    function validation($data, $files) {
      // validation code...
      global $DB;
      // Add field validation check for duplicate Entry.
      if ($dbdent = $DB->get_record('local_attendence', array('uname'=> $data['uname']), '*', IGNORE_MULTIPLE)){
        $cdate = $data['date'];
        // var_dump($dbdent->date);exit;
        // var_dump($cdate);exit;
        if (empty($data['id'])  && $dbdent->date == $cdate && $dbdent->uname == $data['uname']) {
          // var_dump($dbdent->date);exit;
          // var_dump($cdate);exit;
          $errors['date'] = get_string('ddate', 'local_attendence');
          // redirect($CFG->wwwroot.'/moodle/local/attendence/index.php', 'You are already present.');
        }
      }



      if (count($errors) == 0) {
          return true;
      }

      else {
          return $errors;
      }
    }


}
