<?php

require_once(__DIR__ . '/../../config.php');
require_login();
require_once($CFG->dirroot . '/local/attendence/classes/form/edit.php');

global $DB, $USER;

$PAGE->set_url(new moodle_url('/local/attendence/edit.php'));
$PAGE->set_context(\context_system::instance());
$PAGE->set_title('Attendence');
$PAGE->set_heading('Attendence');
$PAGE->navbar->add('Attendence Sheet', new moodle_url('/local/attendence/index.php'));
// $PAGE->navbar->add('');



// form block code for display form
$mform = new edit();
$formid = optional_param('id', null, PARAM_INT);

if ($formid) {
    $formdata = $DB->get_record('user', ['id' => $formid]);
    $formdata->uname=$USER->firstname;
    $mform->set_data($formdata);
}



if ($mform->is_cancelled()) {
    // Go back to manage.php page
    redirect($CFG->wwwroot.'/local/attendence/index.php', 'You are absent');
}



else if ($fromform = $mform->get_data()) {
  // Insert the data into our database table.
  $recordtoinsert = new stdClass();
  $recordtoinsert->uname = $fromform->uname;
  $recordtoinsert->date = $fromform->date;
  $recordtoinsert->status = $fromform->status;
  $recordtoinsert->feedback = '';

  // print_r($recordtoinsert);
  // die;


  $DB->insert_record('local_attendence', $recordtoinsert);

  // Go back to manage.php page
  redirect($CFG->wwwroot.'/local/attendence/index.php', 'Your attendence successfully saved');

}

echo $OUTPUT->header();
$mform->display();
echo $OUTPUT->footer();
