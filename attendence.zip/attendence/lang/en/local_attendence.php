<?php
$string['pluginname'] = 'Attendence';
$string['submit'] = 'Submit';
$string['present'] = 'Present';
$srting['ddate'] = 'You are already present on this date.';
